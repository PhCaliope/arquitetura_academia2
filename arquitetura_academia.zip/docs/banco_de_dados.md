# Modelagem do Banco de Dados

## Tabelas Principais
- FrontEnd_Web: id, descricao, backend_id
- Mobile_App: id, descricao, backend_id
- API_Backend: id, descricao, db_id, biometria_id, pagamento_id, infra_id
- Database_Postgres: id, descricao
- Biometria: id, descricao
- Pagamento: id, descricao
- Infra_AWS: id, descricao

## Relacionamentos
- FrontEnd_Web -> API_Backend
- Mobile_App -> API_Backend
- API_Backend -> Database_Postgres, Biometria, Pagamento, Infra_AWS