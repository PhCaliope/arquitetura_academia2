# Arquitetura do Sistema

## Visão Geral
O sistema é composto pelos seguintes módulos:
- Front-end Web
- Mobile App
- API Backend
- Banco de Dados
- Biometria
- Pagamento
- Infraestrutura AWS

## Fluxo de Dados
1. Usuário acessa Front-end Web ou Mobile App.
2. Requisições passam pelo API Backend.
3. Backend consulta/atualiza dados no Banco, envia dados para Biometria e Pagamento.
4. Respostas retornam ao usuário.

## Diagrama ER / Arquitetura
![Diagrama de Arquitetura](diagrama_arquitetura.png)